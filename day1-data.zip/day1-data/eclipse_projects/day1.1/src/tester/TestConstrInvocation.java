package tester;

import inh.Faculty;
import inh.Student;

public class TestConstrInvocation {

	public static void main(String[] args) {
		Student s1=new Student("Rama", "Kher", 2019, "dac", 80, 12345);
		Faculty f1=new Faculty("Ravi", "Pethe", 10, "ML");
		System.out.println(s1.toString());//fn  ln
		System.out.println(f1.toString());//fn ln 

	}

}
