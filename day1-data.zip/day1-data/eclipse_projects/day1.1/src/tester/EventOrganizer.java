package tester;

import java.util.Scanner;

import inh.Faculty;
import inh.Person;
import inh.Student;

public class EventOrganizer {

	public static void main(String[] args) {
		// create a scanner instance to wrap stdin
		Scanner sc = new Scanner(System.in);
		boolean exit = false;
		System.out.println("Enter max event capacity");
		Person[] participants = new Person[sc.nextInt()];// 100
		int counter = 0;
		while (!exit) {
			System.out.println("Menu 1. Register Student 2. Register Faculty 3. Display Details 10.Exit");
			System.out.println("Choose Option");
			switch (sc.nextInt()) {
			case 1: // Register Student
				if (counter < participants.length) {
					System.out.println("Enter Student details  fn,  ln,  year,  course,  marks,  fees");
					/*
					 * Student s1=new Student(sc.next(), sc.next(), sc.nextInt(), sc.next(),
					 * sc.nextInt(), sc.nextDouble()); participants[counter]=s1;// up casting :
					 * automatic conversion counter++;
					 */
					participants[counter++] = new Student(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.nextInt(),
							sc.nextDouble());
				} else
					System.out.println("Event Full!!!!!!");
				break;

			case 2: // Register Faculty
				if (counter < participants.length) {
					System.out.println("Enter faculty details : fn,ln, exp in yrs , sme");
					participants[counter++] = new Faculty(sc.next(), sc.next(), sc.nextInt(), sc.next());
				} else
					System.out.println("Event Full!!!!!!");
				break;
			case 3: // Display all details
				System.out.println("Participant Details");
				for(int i=0;i<counter;i++)
					System.out.println(participants[i]);//invoke auto toString (HOw ? on Monday) f1, s1,s2,s3,f2
				break;
			case 10: // exit
				exit = true;
				break;
			}
		}
		sc.close();
		System.out.println("Terminating app....");

	}

}
