package tester;

public class TestBasics {

	public static void main(String[] args) {
		int data=100;
		if(data == 100)
			System.out.println("Yes");
		else
			System.out.println("No");

	}

}
