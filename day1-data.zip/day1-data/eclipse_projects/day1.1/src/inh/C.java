package inh;

public class C extends B {
	public C() {
//		super();//implicitly added by javac
		System.out.println("In C");
	}
}
