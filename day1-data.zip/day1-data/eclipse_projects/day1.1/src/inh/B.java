package inh;

public class B extends A {
	public B() {
	//	super();
		System.out.println("in B");
	}
}
