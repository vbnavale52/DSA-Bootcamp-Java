package inh;

//firstName,lastName,grad year,course,fees,marks
public class Student extends Person {
	private int gradYear;
	private String courseName;
	private int marks;
	private double fees;

	// add parameterized constr to init COMPLETE state of a Student
	public Student(String fn, String ln, int year, String course, int marks, double fees) {
//		System.out.println("in sub class");
		super(fn, ln);// explicit constr invocation
		System.out.println("in student's constr");
		gradYear = year;
		courseName = course;
		this.marks = marks;
		this.fees = fees;
	}

	// supply overriding version in Student
	public String toString() {
		// ret COMPLETE details of student
		return "Student " + super.toString() + " Passed in " + gradYear + " course taken " + courseName + " marks "
				+ marks + " fees " + fees;
	}

}
