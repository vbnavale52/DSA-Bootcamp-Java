package inh;

public class A {
	A() {
	//	super();
		System.out.println("in A");
	}
}
