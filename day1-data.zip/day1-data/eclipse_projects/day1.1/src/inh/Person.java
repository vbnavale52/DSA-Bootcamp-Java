package inh;

public class Person {
	private String firstName, lastName;

//constr : init state of the object
	public Person(String firstName, String lastName) {
		super();
		System.out.println("in person's constr");
		this.firstName = firstName;
		this.lastName = lastName;
	}
	//method overriding : SAME name, same signature , same ret type
	//acess specifier : same or wider
	//why override toString 
	//To replace Object's addr representing version(hashCode) by actual details
	public String toString()
	{
		return firstName+" "+lastName;
	}
}
