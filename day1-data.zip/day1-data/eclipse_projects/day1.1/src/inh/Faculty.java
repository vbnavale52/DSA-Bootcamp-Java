package inh;

// firstName,lastName,yrs of experience , sme
public class Faculty extends Person {
	private int expInYears;
	private String sme;

	public Faculty(String fName, String lName, int expInYears, String sme) {
		super(fName, lName);
		System.out.println("in faculty's constr");
		this.expInYears = expInYears;
		this.sme = sme;

	}

	// add overrding form of toString
	public String toString() {
		return "Faculty " + super.toString() + "exp for " + expInYears + " expert in " + sme;
	}
}
